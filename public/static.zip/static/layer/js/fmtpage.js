function fmtPage(pages, page, func){
	if(pages <= 1){
		return '';
	}
	if(!func){
		func 		= 'layer.msg("无法分页");return false;';//changepage(this);
	}
	var addcad 		= 5;
	var prev 		= false;
	var start 		= page - addcad;
	var end 		= page + addcad;
	var last 		= false;
	if(start < 1){
		end 		-= start;
		start 		= 1;
	}
	if(end > pages){
		end 		= pages;
	}
	if(start > 1){
		prev 		= true;
	}
	if(end < pages){
		last 		= true;
	}
	var html 		= '<div class="pages flex vc">';

	if(prev){
		html 		+= '<span onclick="'+func+'" page="1"><span>1</span></span>...';
	}
	for(start; start <= end; start++){
		var cls 	= page == start ? ' class="active"' : '';
		html 		+= '<span onclick="'+func+'" page="'+start+'"><span'+cls+'>'+start+'</span></span>';
	}
	if(last){
		html 		+= '...<span onclick="'+func+'" page="'+pages+'"><span>'+pages+'</span></span>';
	}
	html 			+= '<span><input value="'+page+'" onchange="'+func+'" style="width:50px;border:solid 1px #ddd;text-align:center;padding:4px 2px;top:2px;position: relative;"></span>';
	html 			+= '</div>';
	return html;
}