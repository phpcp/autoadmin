var sockUrl = 'ws://localhost:8089/admin/wss/';
function connectWS(uri, callback, messagecall, errorcall, closecall){
	if(!uri || typeof(uri) != 'string'){
		return layer.msg('请传入uri');
	}
	var ws = null;
	var indd = layer.load(2);
	var wsobj = new WebSocket(sockUrl + uri);
	wsobj.onopen = function(){
		ws = wsobj;
		console.log('连接成功!');
		layer.close(indd);
		callback && callback(ws);
	}
	wsobj.onclose = function(){
		ws = null;
		// layer.open({
		// 	title:'错误信息',
		// 	content: '后台服务被关闭!'
		// });
		if(closecall){
			closecall();
		}else if(errorcall){
			errorcall();
		}
	}
	wsobj.onerror = function(){
		layer.close(indd);
		ws = null;
		layer.open({
			title:'错误信息',
			content: '连接错误!'
		});
		errorcall && errorcall();
	}
	wsobj.onmessage = function(dt){
		layer.close(indd);
		if(dt == 'pong'){
			return;
		}
		if(!dt){
			layer.msg('数据格式错误!');
			return;
		}
		data 	= JSON.parse(dt.data);
		if(typeof(data['type']) != 'string'){
			layer.msg('数据错误!');
			return;
		}
		messagecall && messagecall(data);
		// if(data['type'] == 'version'){
		// 	$('#version').removeAttr('onclick').html(data['data']['version']);
		// }else{
		// 	message(data);
		// }
	}
	return ws;
}